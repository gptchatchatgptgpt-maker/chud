package com.realistictrees;

import com.realistictrees.world.ModFeatures;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RealisticTreesMod implements ModInitializer {

    public static final String MOD_ID = "realistictrees";
    public static final Logger LOGGER  = LoggerFactory.getLogger(MOD_ID);

    /**
     * Registry key that maps to our placed_feature JSON:
     *   data/realistictrees/worldgen/placed_feature/realistic_tree.json
     */
    private static final RegistryKey<PlacedFeature> REALISTIC_TREE_PLACED =
        RegistryKey.of(
            RegistryKeys.PLACED_FEATURE,
            new Identifier(MOD_ID, "realistic_tree")
        );

    @Override
    public void onInitialize() {
        // 1. Register the custom Feature type into Registries.FEATURE (static registry)
        ModFeatures.registerFeatures();

        // 2. Inject our placed feature into forest + taiga biomes
        //    The placed feature is resolved at world-load time from our JSON data file.
        BiomeModifications.addFeature(
            BiomeSelectors.tag(BiomeTags.IS_FOREST)
                .or(BiomeSelectors.tag(BiomeTags.IS_TAIGA)),
            GenerationStep.Feature.VEGETAL_DECORATION,
            REALISTIC_TREE_PLACED
        );

        LOGGER.info("[RealisticTrees] Mod initialized — realistic trees will generate in forest & taiga biomes.");
    }
}
