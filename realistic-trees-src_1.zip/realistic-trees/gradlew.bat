@rem Gradle wrapper for Windows
@rem Requires Java 17+ on PATH

@echo off
setlocal
set SCRIPT_DIR=%~dp0
set WRAPPER_JAR=%SCRIPT_DIR%gradle\wrapper\gradle-wrapper.jar

if not exist "%WRAPPER_JAR%" (
    echo gradle-wrapper.jar not found.
    echo Please download it from:
    echo   https://raw.githubusercontent.com/gradle/gradle/v8.3.0/gradle/wrapper/gradle-wrapper.jar
    echo and place it at: gradle\wrapper\gradle-wrapper.jar
    exit /b 1
)

java -jar "%WRAPPER_JAR%" %*
