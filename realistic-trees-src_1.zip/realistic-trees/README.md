# Realistic Trees — Fabric Mod for Minecraft 1.20.1

Generates tall, organic-looking trees with thin twig-like trunks, sweeping upward
branches in random directions, and irregular dense canopies. Designed to look
stunning with shaders (BSL, Complementary, etc.) and is compatible with Conquest
Reforged — it will automatically use CR wood blocks if the mod is present, and
falls back to vanilla oak blocks otherwise.

## What the trees look like
- **Trunk**: Solid oak log for the lower third, then tapers to a fence post for
  the upper two thirds (fence posts are only 4/16 pixels wide — they look like
  real tree trunks under shaders).
- **Branches**: 5–9 per tree. Each branch picks a random horizontal angle (0–2π),
  then curves upward (a quadratic arc, like a real branch). Branch length and
  spread are randomly chosen using `nextFloat()` (0.0–1.0) so every tree is unique.
- **Leaves**: Dense irregular ellipsoid clusters at every branch tip and a big
  crown on top. ~20% of positions are randomly skipped to give an organic,
  see-through canopy.
- **Spawning**: 2 trees per chunk in forest and taiga biomes.

---

## Building the JAR (one-time, takes ~2 min)

### Prerequisites
| Tool | Version |
|------|---------|
| Java JDK | 17 or newer |
| Internet connection | Required to download Minecraft/Fabric on first build |

### Steps

**Windows:**
```cmd
gradlew.bat build
```
> If it says `gradle-wrapper.jar not found`, download it from the URL printed and
> place it at `gradle\wrapper\gradle-wrapper.jar`, then try again.

**Mac / Linux:**
```bash
chmod +x gradlew
./gradlew build
```

The compiled JAR will appear at:
```
build/libs/realistic-trees-1.0.0.jar
```
(Ignore the `-sources.jar` file — that's just source code.)

---

## Installing into Lunar Client (or any Fabric launcher)

1. Make sure **Fabric Loader 0.14+** and **Fabric API 0.83.0+1.20.1** are installed.
   - In Lunar Client: go to *Mod Manager → Add Mod* and search "Fabric API", then install it.
2. Copy `realistic-trees-1.0.0.jar` into your mods folder:
   - **Lunar Client**: `%APPDATA%\.lunarclient\offline\multiver\mods\1.20.1\`
     (Windows) or `~/.lunarclient/offline/multiver/mods/1.20.1/` (Mac/Linux)
   - **MultiMC / Prism**: right-click instance → *Edit → Mods → Add*
3. Launch the game. In a new world (or newly generated chunks), trees will appear
   in forest and taiga biomes.

> **Note**: Realistic trees only generate in **newly generated chunks** — existing
> worlds won't have them in already-explored areas.

---

## Conquest Reforged compatibility

If Conquest Reforged is installed alongside this mod, the tree generator will
automatically detect CR's wood blocks and prefer them over vanilla oak. No extra
configuration is needed. If CR is not installed the mod works perfectly fine with
vanilla blocks.

---

## Adjusting tree density

Open `src/main/resources/data/realistictrees/worldgen/placed_feature/realistic_tree.json`
and change the `"count"` value:

```json
{ "type": "minecraft:count", "count": 2 }
```

- `1` = sparse  
- `2` = default (similar to vanilla forests)  
- `4` = dense forest  

Rebuild after changing.
